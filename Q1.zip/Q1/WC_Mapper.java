import java.io.IOException;    
import java.util.StringTokenizer;    
import org.apache.hadoop.io.IntWritable;    
import org.apache.hadoop.io.LongWritable;    
import org.apache.hadoop.io.Text;    
import org.apache.hadoop.mapred.MapReduceBase;    
import org.apache.hadoop.mapred.Mapper;    
import org.apache.hadoop.mapred.OutputCollector;    
import org.apache.hadoop.mapred.Reporter;    
public class WC_Mapper extends MapReduceBase implements Mapper<LongWritable,Text,Text,IntWritable>{    
    private final static IntWritable one = new IntWritable(1);    
    private Text word = new Text();    
    public void map(LongWritable key, Text value,OutputCollector<Text,IntWritable> output,     
           Reporter reporter) throws IOException{    
        String line = value.toString();    
        
        //Format for the line is  --> 2018,meltdownattack.com,Spectre Attacks: Exploiting Speculative Execution.,Paul Kocher:Daniel Genkin:Daniel Gruss:Werner Haas 0004:Mike Hamburg:Moritz Lipp:Stefan Mangard:Thomas Prescher 0002:Michael Schwarz 0001:Yuval Yarom
    
        StringTokenizer tokenizer = new StringTokenizer(line, ",");  // Use comma as delimiter  
        
        String token1 = tokenizer.nextToken();
        String token2 = tokenizer.nextToken();
        word.set(token1 + "," + token2);
        output.collect(word, one);
    }    
}
