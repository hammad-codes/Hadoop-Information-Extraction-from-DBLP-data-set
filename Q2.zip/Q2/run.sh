#!/bin/bash
hdfs dfs -rm -r /q2/output
javac -classpath `hadoop classpath` WC_Mapper.java WC_Reducer.java WC_Runner.java
jar cvf WordCount.jar *.class
hadoop jar WordCount.jar WC_Runner /q1/input/Data.csv /q2/output
